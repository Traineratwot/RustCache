# rustcache-client

Cross-platform desktop client for RustCache.

```
rustcache-client.exe gui
rustcache-client.exe run --mode system
rustcache-client.exe ca install
rustcache-client.exe doctor
```

Enter the RustCache host/IP in the GUI and press Connect —
proxy ports are discovered via GET /api/health.
