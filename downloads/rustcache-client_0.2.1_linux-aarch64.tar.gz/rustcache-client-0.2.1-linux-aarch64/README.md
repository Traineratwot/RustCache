# rustcache-client

Cross-platform desktop client for RustCache.

```
rustcache-client gui                 # status window + local proxy
rustcache-client run --mode system   # proxy + system capture
rustcache-client ca install          # install root CA
rustcache-client proxy on|off        # system proxy
rustcache-client doctor              # diagnostics
```

Enter the RustCache host/IP in the GUI and press Connect —
proxy ports are discovered via GET /api/health.
